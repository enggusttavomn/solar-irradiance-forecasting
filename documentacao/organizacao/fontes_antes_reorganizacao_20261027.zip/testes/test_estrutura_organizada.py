"""Contratos da camada publica reorganizada do projeto."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from codigo_fonte.modelos.probabilisticos import DeepAR, DeepNPTS
from codigo_fonte.modelos.referencias_simples.climatologia import prever as climatologia
from codigo_fonte.modelos.referencias_simples.persistencia import prever as persistencia
from codigo_fonte.modelos.referencias_simples.sazonal_ingenuo import prever as sazonal
from codigo_fonte.modelos_tabulares_globais import prever_baselines_mensais
from codigo_fonte.preparacao.base_mensal import carregar_base_mensal


RAIZ = Path(__file__).resolve().parents[1]


def test_cada_modelo_possui_modulo_publico_proprio() -> None:
    esperados = {
        "modelos/referencias_simples/persistencia.py",
        "modelos/referencias_simples/sazonal_ingenuo.py",
        "modelos/referencias_simples/climatologia.py",
        "modelos/tabulares/xgboost.py",
        "modelos/tabulares/mlp.py",
        "modelos/recorrentes/rnn.py",
        "modelos/recorrentes/lstm.py",
        "modelos/recorrentes/dilated_rnn.py",
        "modelos/probabilisticos/deepar.py",
        "modelos/probabilisticos/deepnpts.py",
    }
    encontrados = {
        caminho.relative_to(RAIZ / "codigo_fonte").as_posix()
        for caminho in (RAIZ / "codigo_fonte" / "modelos").rglob("*.py")
        if caminho.name != "__init__.py"
    }
    assert esperados <= encontrados


def test_referencias_publicas_reproduzem_motor_canonico() -> None:
    base = carregar_base_mensal()
    canonicas = prever_baselines_mensais(base)
    np.testing.assert_allclose(persistencia(base), canonicas["Persistencia"])
    np.testing.assert_allclose(sazonal(base), canonicas["SazonalIngenuo"])
    np.testing.assert_allclose(climatologia(base), canonicas["Climatologia"])


def test_classes_probabilisticas_publicas_correspondem_aos_modelos() -> None:
    assert DeepAR.nome_modelo == "DeepAR"
    assert DeepNPTS.nome_modelo == "DeepNPTS"


def test_indice_de_artigos_aponta_para_os_manuscritos_reais() -> None:
    assert (RAIZ / "artigos" / "ieee" / "artigo.tex").is_file()
    assert (RAIZ / "artigos" / "btsym26" / "main.tex").is_file()
    assert (RAIZ / "artigos" / "revista_unificado" / "main.tex").is_file()
