"""Migração local: uma árvore de código e uma árvore de resultados."""
from pathlib import Path
import ast
import hashlib
import json
import os
import re
import zipfile

ROOT = Path(os.environ.get('REORGANIZACAO_RAIZ', str(Path(__file__).resolve().parents[1])))
PLAN = ROOT / 'tmp/plano_reorganizacao_codigo.json'
REGISTRY = ROOT / 'documentacao/organizacao/reorganizacao_codigo_20261027.json'
ARCHIVE = ROOT / 'documentacao/organizacao/fontes_antes_reorganizacao_20261027.zip'


def module(path):
    return path.removesuffix('.py').replace('/', '.').removesuffix('.__init__')


def group(path):
    groups = {
        'coleta': 'coleta_e_preparacao', 'preparacao': 'coleta_e_preparacao',
        'treinamento': 'experimentos', 'quantizacao': 'experimentos',
        'otimizacao': 'experimentos', 'operacao': 'acompanhamento',
        'auditoria': 'analises_e_relatorios', 'relatorios': 'analises_e_relatorios',
        'visualizacao': 'analises_e_relatorios', 'avaliacao': 'analises_e_relatorios',
        'publicacao': 'publicacoes', 'apresentacoes': 'publicacoes',
        'infraestrutura': 'utilitarios',
    }
    parts = path.split('/')
    if parts[0] == 'codigo_fonte' and len(parts) > 2:
        parts[1] = groups.get(parts[1], parts[1])
    return '/'.join(parts)


def prepare():
    command_plan = json.loads((ROOT/'tmp/mapeamento_comandos_unificados.json').read_text(encoding='utf-8'))
    moves, aliases, removed = {}, {}, []
    for item in command_plan['arquivos']:
        old = item['origem']; new = item['destino']
        if new is None:
            removed.append(old)
        else:
            new = group(new)
            aliases[old] = new
            if item['acao'] == 'mover': moves[old] = new
            else: removed.append(old)
    science = {
        'coleta_e_preparacao': ['dados_horarios_nsrdb','historico_nsrdb_expandido','historico_nsrdb_agregacao','contexto_geografico','contexto_meteorologico','preprocessamento','features'],
        'modelos': ['modelos_baselines_adicionais','timesnet_horario'],
        'modelos/referencias_simples': ['baselines','climatologia_cache_localidade','arima_checkpoint_compacto'],
        'modelos/recorrentes': ['dilated_rnn_direta','modelos_neurais_globais'],
        'modelos/tabulares': ['modelos_tabulares_globais'],
        'modelos/probabilisticos': ['modelos_globais_gluonts','redes_deepnpts_registradas'],
        'experimentos': ['otimizacao_timesnet_mensal','otimizacao_timesnet_resolucoes','treinamento_timesnet_otimizacao','treinamento_timesnet_quantizado_resolucoes','treinamento_timesnet_resolucoes','quantizacao_referencias','quantizacao_timesnet'],
        'analises_e_relatorios': ['graficos','gerar_figuras_benchmark_completo','consolidar_baselines_adicionais'],
        'publicacoes': ['artefatos_artigo_unificado','gerar_tabelas_baselines_adicionais'],
        'utilitarios': ['configuracao','utilitarios','artefatos_fragmentados','reprodutibilidade'],
    }
    for folder, names in science.items():
        for name in names: moves[f'codigo_fonte/{name}.py'] = f'codigo_fonte/{folder}/{name}.py'
    for p in (ROOT/'codigo_fonte').glob('experimento_*.py'):
        moves[p.relative_to(ROOT).as_posix()] = 'codigo_fonte/experimentos/'+p.name
    moves.update({
        'codigo_fonte/localidades_ev.py':'codigo_fonte/coleta_e_preparacao/localidades.py',
        'codigo_fonte/dados_mensais_globais.py':'codigo_fonte/coleta_e_preparacao/base_mensal.py',
        'codigo_fonte/dilated_rnn.py':'codigo_fonte/modelos/recorrentes/nucleo_dilated_rnn.py',
        'codigo_fonte/avaliacao.py':'codigo_fonte/analises_e_relatorios/metricas.py',
        'codigo_fonte/figuras_experimento_canonico.py':'codigo_fonte/analises_e_relatorios/figuras_resultados.py',
    })
    facades = {
        'codigo_fonte/modelos.py':'codigo_fonte/modelos/__init__.py',
        'codigo_fonte/coleta/api_nsrdb.py':'codigo_fonte/coleta_e_preparacao/preprocessamento.py',
        'codigo_fonte/coleta/localidades.py':'codigo_fonte/coleta_e_preparacao/localidades.py',
        'codigo_fonte/preparacao/base_mensal.py':'codigo_fonte/coleta_e_preparacao/base_mensal.py',
        'codigo_fonte/preparacao/limpeza_dados.py':'codigo_fonte/coleta_e_preparacao/preprocessamento.py',
        'codigo_fonte/experimento/avaliacao_mensal.py':'codigo_fonte/experimentos/experimento_mensal_canonico.py',
        'codigo_fonte/experimento/metricas.py':'codigo_fonte/analises_e_relatorios/metricas.py',
        'codigo_fonte/experimento/reprodutibilidade.py':'codigo_fonte/utilitarios/reprodutibilidade.py',
        'codigo_fonte/visualizacao/figuras_resultados.py':'codigo_fonte/analises_e_relatorios/figuras_resultados.py',
    }
    removed.extend(facades)
    for folder in ['coleta','preparacao','experimento','visualizacao']:
        removed.append(f'codigo_fonte/{folder}/__init__.py')
    aliases.update(moves); aliases.update(facades)
    for p in (ROOT/'tests').glob('*.py'):
        old=p.relative_to(ROOT).as_posix()
        if p.name=='test_json_atomico.py': aliases[old]='testes/test_json_atomico.py'; removed.append(old)
        else: moves[old]='testes/'+p.name; aliases[old]=moves[old]
    aliases['scripts/COMANDOS.md']='codigo_fonte/COMANDOS.md'
    removed.extend(['scripts/README.md','scripts/COMANDOS.md','executaveis/README.md','tests/README.md','output/README.md'])
    modules={module(old):module(new) for old,new in aliases.items() if old.endswith('.py') and module(old)!=module(new)}
    modules.pop('codigo_fonte.modelos',None)
    record={'data':'2026-10-27','objetivo':'Unificar código por tarefa e saídas em resultados, removendo fachadas redundantes.',
            'fontes_arquivadas':ARCHIVE.relative_to(ROOT).as_posix(),
            'arquivos':aliases,'modulos':modules,'movimentos':moves,'removidos':sorted(set(removed)),
            'pastas':{'relatorios':'resultados/relatorios','output/pdf':'resultados/pdf','tests':'testes'},
            'fontes_antes':{}}
    paths=[]
    for folder in ['codigo_fonte','scripts','executaveis','testes','tests']:
        paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    paths.extend(ROOT/name for name in ['treinar_todas_localidades.py','reavaliar_modelos_salvos.py','executar_avaliacao_mensal_canonica.py','gerar_figuras_avaliacao_canonica.py','README.md','MAPA_DO_PROJETO.md','pyproject.toml','.gitignore','Abrir painel de progresso.cmd'])
    assert not ARCHIVE.exists(), 'Migração já preparada; não sobrescrever evidências.'
    with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(paths)):
            name=p.relative_to(ROOT).as_posix(); data=p.read_bytes()
            z.writestr(name,data); record['fontes_antes'][name]=hashlib.sha256(data).hexdigest()
    record['sha256_arquivo_fontes']=hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    assert len(set(moves.values()))==len(moves), 'Colisão de implementações.'
    for old,new in moves.items():
        assert (ROOT/old).is_file(),old
        assert not (ROOT/new).exists() or new in removed,(old,new)
    PLAN.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    REGISTRY.write_text(PLAN.read_text(encoding='utf-8'),encoding='utf-8')
    print('Plano e ZIP preparados:',len(moves),'movimentos,',len(set(removed)),'fachadas/índices antigos,',len(paths),'fontes preservadas.')


def transform(text, old, new, record):
    modules=record['modulos']; paths=record['arquivos']
    tree=ast.parse(text,filename=old)
    lines=text.splitlines(keepends=True); starts=[0]
    for line in lines: starts.append(starts[-1]+len(line))
    def offset(line,col):
        return starts[line-1]+len(lines[line-1].encode('utf-8')[:col].decode('utf-8'))
    def mapped_mod(name): return modules.get(name,name)
    edits=[]
    package=module(old) if old.endswith('/__init__.py') else module(old).rpartition('.')[0]
    bare={k:v for k,v in modules.items() if '.' not in k}
    for k,v in modules.items():
        if k.startswith('executaveis.'): bare[k.rpartition('.')[2]]=v
    for node in ast.walk(tree):
        out=[]
        if isinstance(node,ast.ImportFrom):
            base=node.module or ''; original_base=base
            if node.level:
                parts=package.split('.') if package else []
                parts=parts[:len(parts)-node.level+1]
                base='.'.join(parts+([base] if base else []))
            if base in bare: base=bare[base]
            mapped_base=mapped_mod(base)
            if node.module is None or base in ['codigo_fonte','scripts','executaveis'] or node.level:
                for alias in node.names:
                    full=base+'.'+alias.name; dest=mapped_mod(full)
                    if dest!=full:
                        parent,_,name=dest.rpartition('.'); local=alias.asname or alias.name
                        out.append(f'from {parent} import {name}'+(f' as {local}' if local!=name else ''))
                    else: out.append(f'from {mapped_base} import {alias.name}'+(f' as {alias.asname}' if alias.asname else ''))
            elif mapped_base!=base or base!=original_base:
                out=['from '+mapped_base+' import '+', '.join(a.name+(f' as {a.asname}' if a.asname else '') for a in node.names)]
        elif isinstance(node,ast.Import):
            for alias in node.names:
                dest=modules.get(alias.name,bare.get(alias.name,alias.name))
                if dest!=alias.name:
                    local=alias.asname or (alias.name if '.' not in alias.name else None)
                    out.append('import '+dest+(f' as {local}' if local else ''))
                else: out.append('import '+alias.name+(f' as {alias.asname}' if alias.asname else ''))
            if all(modules.get(a.name,bare.get(a.name,a.name))==a.name for a in node.names): out=[]
        if out:
            indent=' '*node.col_offset
            edits.append((offset(node.lineno,node.col_offset),offset(node.end_lineno,node.end_col_offset),('\n'+indent).join(out)))
    for start,end,value in sorted(edits,reverse=True): text=text[:start]+value+text[end:]
    pattern=re.compile(r'(?<![\w.])('+ '|'.join(re.escape(k) for k in sorted(modules,key=len,reverse=True))+r')(?![\w.])')
    text='\n'.join(line if line.lstrip().startswith(('from ','import ')) else pattern.sub(lambda m:modules[m.group()],line) for line in text.split('\n'))
    replacements={k:v for k,v in paths.items() if k!=v}
    pattern=re.compile('|'.join(re.escape(k) for k in sorted(replacements,key=len,reverse=True)))
    text=pattern.sub(lambda m:replacements[m.group()],text)
    # A target path must not be remapped a second time by the broader folder rule.
    text=text.replace('output/pdf','resultados/pdf').replace('output\\\\pdf','resultados\\\\pdf')
    text=re.sub(r'(?<![\w/])relatorios/', 'resultados/relatorios/',text)
    text=re.sub(r'(/\s*[\'"])relatorios([\'"])',r'\1resultados/relatorios\2',text)
    text=re.sub(r'(/\s*[\'"])output([\'"])\s*/\s*([\'"])pdf\3',r'\1resultados\2 / "pdf"',text)
    old_depth=len(Path(old).parts)-1; new_depth=len(Path(new).parts)-1
    pattern=re.compile(r'((?:_?Path)\(__file__\)(?:\.resolve\(\))?\.parents)\[(\d+)\]')
    text=pattern.sub(lambda m:m[1]+'['+str(int(m[2])+new_depth-old_depth if int(m[2])>=old_depth else int(m[2]))+']',text)
    if old_depth==0:
        text=re.sub(r'((?:_?Path)\(__file__\)(?:\.resolve\(\))?)\.parent\b',lambda m:m[1]+f'.parents[{new_depth}]',text)
    pattern=re.compile(r'((?:_?Path)\(__file__\)(?:\.resolve\(\))?)\.with_name\(([\'"])([^\'"]+\.py)\2\)')
    def sibling(m):
        original=(Path(old).parent/m[3]).as_posix(); target=paths.get(original)
        return m[1]+f'.parents[{new_depth}] / '+repr(target) if target else m.group()
    text=pattern.sub(sibling,text)
    ast.parse(text,filename=new)
    return text


def rewrite():
    record=json.loads(PLAN.read_text(encoding='utf-8'))
    with zipfile.ZipFile(ARCHIVE) as archive:
        for old in record['fontes_antes']:
            if not old.endswith('.py') or old in record['removidos']: continue
            new=record['movimentos'].get(old,old); target=ROOT/new
            assert target.exists(),new
            original=archive.read(old).decode('utf-8-sig')
            target.write_text(transform(original,old,new,record),encoding='utf-8',newline='\n')
        old='tests/test_json_atomico.py'; target=ROOT/'testes/test_json_atomico.py'
        extra=transform(archive.read(old).decode('utf-8-sig'),old,'testes/test_json_atomico.py',record)
        target.write_text(target.read_text(encoding='utf-8')+'\n\n'+extra,encoding='utf-8',newline='\n')
    additions={
        'codigo_fonte/coleta_e_preparacao/localidades.py':'LOCALIDADES = LOCALIDADES_EV\nlistar_localidades = dataframe_localidades\n',
        'codigo_fonte/coleta_e_preparacao/base_mensal.py':'BaseMensal = BaseMensalGlobal\nSerieMensal = SerieMensalGlobal\ncarregar_base_mensal = carregar_base_mensal_global\ncriar_matrizes_recorrentes = matrizes_keras\nauditar_dados_diarios = auditar_arquivos_diarios\n',
        'codigo_fonte/coleta_e_preparacao/preprocessamento.py':'coletar_ghi = coletar_ghi_nrel\nconsultar_anos_disponiveis = consultar_anos_disponiveis_nsrdb\nlimpar_ghi = limpar_serie_ghi\nagregar_por_dia = garantir_resolucao_diaria\nagregar_por_mes = garantir_resolucao_mensal\n',
        'codigo_fonte/experimentos/experimento_mensal_canonico.py':'Configuracao = ConfiguracaoExperimento\nexecutar = executar_experimento\n',
    }
    for name,extra in additions.items():
        p=ROOT/name; text=p.read_text(encoding='utf-8'); marker=re.search(r'^if __name__\s*==',text,re.M)
        point=marker.start() if marker else len(text)
        p.write_text(text[:point]+'\n\n'+extra+'\n'+text[point:],encoding='utf-8',newline='\n')
    for folder in ['coleta_e_preparacao','experimentos','analises_e_relatorios','acompanhamento','publicacoes','utilitarios']:
        (ROOT/'codigo_fonte'/folder/'__init__.py').write_text('"""'+folder.replace('_',' ')+'.\"\"\"\n',encoding='utf-8')
    print('Imports, caminhos e fachadas absorvidas atualizados.')


if __name__=='__main__':
    import sys
    {'preparar':prepare,'reescrever':rewrite}[sys.argv[1]]()
