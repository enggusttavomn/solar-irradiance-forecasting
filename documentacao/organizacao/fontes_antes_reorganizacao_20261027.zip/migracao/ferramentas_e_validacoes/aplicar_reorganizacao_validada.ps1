#requires -Version 5.1
<#
Aplica a previa validada por movimentos reversiveis e copias de documentos.
Nao remove backups nem apaga arquivos. O plano e os hashes sao conferidos
antes da primeira alteracao. Em caso de falha, desfaz as acoes em ordem inversa.
Os testes na arvore principal devem ser executados depois da aplicacao.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$workspaceEsperado = 'C:\Users\gusta\Downloads\EA019(TCC)'
$workspace = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..')).TrimEnd('\')
if (-not $workspace.Equals($workspaceEsperado, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Este script so pode operar no workspace fixo verificado.'
}

function Assert-WorkspacePath {
    param([Parameter(Mandatory=$true)][string]$Path)
    $normalizado = [IO.Path]::GetFullPath($Path).TrimEnd('\')
    if (-not $normalizado.Equals($workspace, [StringComparison]::OrdinalIgnoreCase) -and
        -not $normalizado.StartsWith($workspace + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw ('Caminho fora do workspace: ' + $normalizado)
    }
    return $normalizado
}

function Get-WorkspacePath {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    if ([IO.Path]::IsPathRooted($RelativePath)) {
        throw ('Era esperado um caminho relativo: ' + $RelativePath)
    }
    return (Assert-WorkspacePath (Join-Path $workspace $RelativePath))
}

function Get-LongPath {
    param([Parameter(Mandatory=$true)][string]$Path)
    return ('\\?\' + $Path)
}

function Test-AnyPath {
    param([Parameter(Mandatory=$true)][string]$Path)
    try {
        [void][IO.File]::GetAttributes((Get-LongPath $Path))
        return $true
    } catch [IO.FileNotFoundException] {
        return $false
    } catch [IO.DirectoryNotFoundException] {
        return $false
    }
}

function Assert-NoReparseAncestors {
    param([Parameter(Mandatory=$true)][string]$Path)
    $atual = Assert-WorkspacePath $Path
    while ($atual.Length -ge $workspace.Length) {
        if (Test-AnyPath $atual) {
            $atributos = [IO.File]::GetAttributes((Get-LongPath $atual))
            if ($atributos -band [IO.FileAttributes]::ReparsePoint) {
                throw ('Link ou junction nao permitido: ' + $atual)
            }
        }
        if ($atual.Equals($workspace, [StringComparison]::OrdinalIgnoreCase)) { break }
        $atual = [IO.Path]::GetDirectoryName($atual)
    }
}

function Assert-NoReparseTree {
    param([Parameter(Mandatory=$true)][string]$Path)
    Assert-NoReparseAncestors $Path
    if (-not (Test-AnyPath $Path)) { throw ('Origem ausente: ' + $Path) }
    $atributosRaiz = [IO.File]::GetAttributes((Get-LongPath $Path))
    if (-not ($atributosRaiz -band [IO.FileAttributes]::Directory)) { return }
    $pilha = New-Object 'System.Collections.Generic.Stack[string]'
    $pilha.Push((Get-LongPath $Path))
    while ($pilha.Count -gt 0) {
        foreach ($entrada in [IO.Directory]::EnumerateFileSystemEntries($pilha.Pop())) {
            $atributos = [IO.File]::GetAttributes($entrada)
            if ($atributos -band [IO.FileAttributes]::ReparsePoint) {
                throw ('Link ou junction dentro da origem: ' + $entrada)
            }
            if ($atributos -band [IO.FileAttributes]::Directory) { $pilha.Push($entrada) }
        }
    }
}

function Get-Sha256 {
    param([Parameter(Mandatory=$true)][string]$Path)
    Assert-NoReparseAncestors $Path
    if (-not (Test-AnyPath $Path)) { throw ('Arquivo para hash ausente: ' + $Path) }
    $hash = [Security.Cryptography.SHA256]::Create()
    $stream = $null
    try {
        $stream = [IO.File]::OpenRead((Get-LongPath $Path))
        return ([BitConverter]::ToString($hash.ComputeHash($stream))).Replace('-', '').ToLowerInvariant()
    } finally {
        if ($null -ne $stream) { $stream.Dispose() }
        $hash.Dispose()
    }
}

function Assert-Sha256 {
    param([string]$Path, [string]$Expected)
    if ($Expected -notmatch '^[a-fA-F0-9]{64}$') { throw ('SHA-256 invalido: ' + $Path) }
    if ((Get-Sha256 $Path) -ne $Expected.ToLowerInvariant()) {
        throw ('Arquivo mudou depois da preparacao: ' + $Path)
    }
}

function Ensure-Directory {
    param([Parameter(Mandatory=$true)][string]$Path)
    $alvo = Assert-WorkspacePath $Path
    Assert-NoReparseAncestors $alvo
    if (Test-AnyPath $alvo) {
        if (-not ([IO.File]::GetAttributes((Get-LongPath $alvo)) -band [IO.FileAttributes]::Directory)) {
            throw ('Era esperado um diretorio: ' + $alvo)
        }
        return
    }
    [void](New-Item -ItemType Directory -Path $alvo -Force)
    Assert-NoReparseAncestors $alvo
}

$previa = Get-WorkspacePath 'tmp\reorganizacao_previa_20261027'
$backup = Get-WorkspacePath 'tmp\reorganizacao_backup_20261027'
$planoPath = Get-WorkspacePath 'tmp\aplicacao_organizacao_20261027.json'
$registroPath = Assert-WorkspacePath (Join-Path $previa 'documentacao\organizacao\reorganizacao_codigo_20261027.json')
$journalPath = Assert-WorkspacePath (Join-Path $backup 'journal.jsonl')

Assert-NoReparseAncestors $workspace
Assert-NoReparseAncestors $previa
Assert-NoReparseAncestors $backup
Assert-NoReparseAncestors $planoPath
Assert-NoReparseAncestors $registroPath
if (-not (Test-AnyPath $previa)) { throw 'A previa validada nao existe.' }
if (Test-AnyPath $backup) { throw 'O destino de backup ja existe; nenhuma alteracao foi feita.' }
if (-not (Test-AnyPath $planoPath)) { throw 'O plano de substituicoes ainda nao existe.' }

$plano = Get-Content -LiteralPath $planoPath -Raw -Encoding UTF8 | ConvertFrom-Json
$registro = Get-Content -LiteralPath $registroPath -Raw -Encoding UTF8 | ConvertFrom-Json
if (@($registro.fontes_antes.PSObject.Properties).Count -eq 0) { throw 'Registro sem fontes_antes.' }
if (@($registro.fontes_depois.PSObject.Properties).Count -eq 0) { throw 'Registro sem fontes_depois.' }
if (-not ($plano.PSObject.Properties.Name -contains 'substituicoes')) { throw 'Plano sem substituicoes.' }

# Todas as fontes de entrada sao verificadas antes de criar o backup.
foreach ($fonte in $registro.fontes_antes.PSObject.Properties) {
    Assert-Sha256 (Get-WorkspacePath $fonte.Name) ([string]$fonte.Value)
}
foreach ($fonte in $registro.fontes_depois.PSObject.Properties) {
    $caminhoPrevia = Assert-WorkspacePath (Join-Path $previa $fonte.Name)
    Assert-Sha256 $caminhoPrevia ([string]$fonte.Value)
}
Assert-Sha256 (Assert-WorkspacePath (Join-Path $previa $registro.fontes_arquivadas)) ([string]$registro.sha256_arquivo_fontes)

$movimentos = New-Object 'System.Collections.Generic.List[object]'
function Add-PlannedMove {
    param([string]$From, [string]$To, [string]$Kind)
    $movimentos.Add([pscustomobject]@{
        Origem = (Assert-WorkspacePath $From)
        Destino = (Assert-WorkspacePath $To)
        Tipo = $Kind
    })
}

Add-PlannedMove (Get-WorkspacePath 'codigo_fonte') (Join-Path $backup 'pastas\codigo_fonte') 'diretorio'
Add-PlannedMove (Join-Path $previa 'codigo_fonte') (Get-WorkspacePath 'codigo_fonte') 'diretorio'
Add-PlannedMove (Get-WorkspacePath 'testes') (Join-Path $backup 'pastas\testes') 'diretorio'
Add-PlannedMove (Join-Path $previa 'testes') (Get-WorkspacePath 'testes') 'diretorio'
foreach ($pasta in @('scripts', 'executaveis', 'tests')) {
    Add-PlannedMove (Get-WorkspacePath $pasta) (Join-Path $backup ('pastas\' + $pasta)) 'diretorio'
}
foreach ($arquivo in @('executar_avaliacao_mensal_canonica.py', 'gerar_figuras_avaliacao_canonica.py', 'reavaliar_modelos_salvos.py', 'treinar_todas_localidades.py')) {
    Add-PlannedMove (Get-WorkspacePath $arquivo) (Join-Path $backup ('arquivos_raiz\' + $arquivo)) 'arquivo'
}
Add-PlannedMove (Get-WorkspacePath 'relatorios') (Get-WorkspacePath 'resultados\relatorios') 'diretorio'
Add-PlannedMove (Get-WorkspacePath 'output\pdf') (Get-WorkspacePath 'resultados\pdf') 'diretorio'
Add-PlannedMove (Get-WorkspacePath 'output') (Join-Path $backup 'pastas\output') 'diretorio'

# Simula os destinos desocupados por movimentos anteriores, sem mover nada.
$vazios = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($movimento in $movimentos) {
    Assert-NoReparseTree $movimento.Origem
    Assert-NoReparseAncestors $movimento.Destino
    $eDiretorio = [bool]([IO.File]::GetAttributes((Get-LongPath $movimento.Origem)) -band [IO.FileAttributes]::Directory)
    if (($movimento.Tipo -eq 'diretorio') -ne $eDiretorio) { throw ('Tipo de origem incorreto: ' + $movimento.Origem) }
    if ((Test-AnyPath $movimento.Destino) -and -not $vazios.Contains($movimento.Destino)) {
        throw ('Destino de movimento ocupado: ' + $movimento.Destino)
    }
    [void]$vazios.Add($movimento.Origem)
    [void]$vazios.Remove($movimento.Destino)
}

foreach ($pastaAntiga in @('scripts', 'executaveis', 'tests', 'relatorios', 'output')) {
    if (Test-AnyPath (Assert-WorkspacePath (Join-Path $previa $pastaAntiga))) {
        throw ('A previa ainda contem uma area antiga: ' + $pastaAntiga)
    }
}

function Get-SourceAfterPlannedMoves {
    param([string]$RelativePath)
    $relativo = $RelativePath.Replace('\', '/')
    if ($relativo.StartsWith('codigo_fonte/') -or $relativo.StartsWith('testes/')) {
        return (Assert-WorkspacePath (Join-Path $previa $relativo))
    }
    if ($relativo.StartsWith('resultados/relatorios/')) {
        return (Get-WorkspacePath ('relatorios/' + $relativo.Substring('resultados/relatorios/'.Length)))
    }
    if ($relativo.StartsWith('resultados/pdf/')) {
        return (Get-WorkspacePath ('output/pdf/' + $relativo.Substring('resultados/pdf/'.Length)))
    }
    return (Get-WorkspacePath $relativo)
}

$substituicoes = New-Object 'System.Collections.Generic.List[object]'
$destinosArquivos = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($item in @($plano.substituicoes)) {
    foreach ($campo in @('destino', 'sha256_antes', 'sha256_depois')) {
        if (-not ($item.PSObject.Properties.Name -contains $campo)) { throw ('Substituicao sem campo: ' + $campo) }
    }
    $relativo = ([string]$item.destino).Replace('\', '/')
    if ($relativo -match '^(scripts|executaveis|tests|relatorios|output)(/|$)') { throw ('Plano recria uma area antiga: ' + $relativo) }
    $destino = Get-WorkspacePath $relativo
    if (-not $destinosArquivos.Add($destino)) { throw ('Substituicao duplicada: ' + $destino) }
    $origemPrevia = Assert-WorkspacePath (Join-Path $previa $relativo)
    Assert-Sha256 $origemPrevia ([string]$item.sha256_depois)
    $origemAntes = Get-SourceAfterPlannedMoves $relativo
    Assert-NoReparseAncestors $origemAntes
    if ([string]::IsNullOrEmpty([string]$item.sha256_antes)) {
        if (Test-AnyPath $origemAntes) { throw ('Era esperado um arquivo novo: ' + $destino) }
    } else {
        Assert-Sha256 $origemAntes ([string]$item.sha256_antes)
    }
    $jaInstaladoNoMovimento = $relativo.StartsWith('codigo_fonte/') -or $relativo.StartsWith('testes/')
    if ($jaInstaladoNoMovimento -and ([string]$item.sha256_antes -ne [string]$item.sha256_depois)) {
        throw ('Substituicao em arvore instalada por movimento deve ser identica: ' + $relativo)
    }
    $backupArquivo = Assert-WorkspacePath (Join-Path $backup ('arquivos\' + $relativo))
    if (Test-AnyPath $backupArquivo) { throw ('Backup de arquivo ja ocupado: ' + $backupArquivo) }
    $substituicoes.Add([pscustomobject]@{
        Relativo = $relativo
        Destino = $destino
        OrigemPrevia = $origemPrevia
        Backup = $backupArquivo
        Antes = [string]$item.sha256_antes
        Depois = [string]$item.sha256_depois
        JaInstaladoNoMovimento = $jaInstaladoNoMovimento
    })
}

$acoes = New-Object 'System.Collections.Generic.List[object]'
$utf8SemBom = New-Object Text.UTF8Encoding($false)
function Write-Journal {
    param([string]$Event, [object]$Details)
    $evento = [ordered]@{ utc = [DateTime]::UtcNow.ToString('o'); evento = $Event; detalhes = $Details }
    $bytes = $utf8SemBom.GetBytes((ConvertTo-Json -InputObject $evento -Compress -Depth 12) + [Environment]::NewLine)
    $stream = New-Object IO.FileStream($journalPath, [IO.FileMode]::Append, [IO.FileAccess]::Write, [IO.FileShare]::Read)
    try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush($true) }
    finally { $stream.Dispose() }
}

function Invoke-ReversibleMove {
    param([string]$From, [string]$To)
    $origem = Assert-WorkspacePath $From
    $destino = Assert-WorkspacePath $To
    Assert-NoReparseAncestors $origem
    Assert-NoReparseAncestors $destino
    if (-not (Test-AnyPath $origem)) { throw ('Origem deixou de existir: ' + $origem) }
    if (Test-AnyPath $destino) { throw ('Destino deixou de estar vazio: ' + $destino) }
    Ensure-Directory ([IO.Path]::GetDirectoryName($destino))
    $acao = [pscustomobject]@{ Tipo='movimento'; Origem=$origem; Destino=$destino; Aplicada=$false }
    $acoes.Add($acao)
    Write-Journal 'movimento_iniciado' $acao
    Move-Item -LiteralPath $origem -Destination $destino
    $acao.Aplicada = $true
    Write-Journal 'movimento_concluido' $acao
}

function Invoke-ReversibleReplacement {
    param([object]$Item)
    if ($Item.JaInstaladoNoMovimento) {
        Assert-Sha256 $Item.Destino $Item.Depois
        Write-Journal 'arquivo_instalado_com_diretorio' $Item.Relativo
        return
    }
    Assert-NoReparseAncestors $Item.Destino
    Assert-Sha256 $Item.OrigemPrevia $Item.Depois
    $existia = -not [string]::IsNullOrEmpty($Item.Antes)
    if ($existia) { Assert-Sha256 $Item.Destino $Item.Antes }
    elseif (Test-AnyPath $Item.Destino) { throw ('Arquivo novo passou a existir: ' + $Item.Destino) }
    $acao = [pscustomobject]@{
        Tipo='substituicao'; Destino=$Item.Destino; Backup=$Item.Backup
        Existia=$existia; OriginalSalvo=$false; InstalacaoIniciada=$false
    }
    $acoes.Add($acao)
    Write-Journal 'substituicao_iniciada' $acao
    if ($existia) {
        Ensure-Directory ([IO.Path]::GetDirectoryName($Item.Backup))
        Copy-Item -LiteralPath $Item.Destino -Destination $Item.Backup
        Assert-Sha256 $Item.Backup $Item.Antes
        $acao.OriginalSalvo = $true
    }
    Ensure-Directory ([IO.Path]::GetDirectoryName($Item.Destino))
    $acao.InstalacaoIniciada = $true
    Copy-Item -LiteralPath $Item.OrigemPrevia -Destination $Item.Destino -Force
    Assert-Sha256 $Item.Destino $Item.Depois
    Write-Journal 'substituicao_concluida' $acao
}

try {
    Ensure-Directory $backup
    Write-Journal 'inicio' ([ordered]@{workspace=$workspace; previa=$previa; plano=$planoPath; movimentos=$movimentos.Count; substituicoes=$substituicoes.Count})
    foreach ($movimento in $movimentos) { Invoke-ReversibleMove $movimento.Origem $movimento.Destino }
    foreach ($item in $substituicoes) { Invoke-ReversibleReplacement $item }

    foreach ($fonte in $registro.fontes_depois.PSObject.Properties) {
        Assert-Sha256 (Get-WorkspacePath $fonte.Name) ([string]$fonte.Value)
    }
    foreach ($item in $substituicoes) { Assert-Sha256 $item.Destino $item.Depois }
    foreach ($pastaAntiga in @('scripts', 'executaveis', 'tests', 'relatorios', 'output')) {
        if (Test-AnyPath (Get-WorkspacePath $pastaAntiga)) { throw ('Area antiga permaneceu na raiz: ' + $pastaAntiga) }
    }
    Write-Journal 'aplicacao_concluida' ([ordered]@{backup=$backup; testes_principal_pendentes=$true})
    Write-Output 'Reorganizacao aplicada; nenhum backup foi removido.'
    Write-Output ('Journal e originais: ' + $backup)
    Write-Output 'Execute a suite de testes na arvore principal antes de qualquer limpeza posterior.'
} catch {
    $erroAplicacao = $_
    try { if (Test-AnyPath $backup) { Write-Journal 'erro_aplicacao' $erroAplicacao.Exception.Message } } catch { }
    $falhasRollback = New-Object 'System.Collections.Generic.List[string]'
    for ($indice = $acoes.Count - 1; $indice -ge 0; $indice--) {
        $acao = $acoes[$indice]
        try {
            if ($acao.Tipo -eq 'substituicao') {
                Assert-NoReparseAncestors $acao.Destino
                if ($acao.Existia -and $acao.OriginalSalvo) {
                    Assert-NoReparseAncestors $acao.Backup
                    Ensure-Directory ([IO.Path]::GetDirectoryName($acao.Destino))
                    Copy-Item -LiteralPath $acao.Backup -Destination $acao.Destino -Force
                } elseif (-not $acao.Existia -and $acao.InstalacaoIniciada -and (Test-AnyPath $acao.Destino)) {
                    $relativo = $acao.Destino.Substring($workspace.Length + 1)
                    $novoSalvo = Assert-WorkspacePath (Join-Path $backup ('rollback_novos\' + $relativo))
                    if (Test-AnyPath $novoSalvo) { throw ('Destino de rollback ocupado: ' + $novoSalvo) }
                    Ensure-Directory ([IO.Path]::GetDirectoryName($novoSalvo))
                    Move-Item -LiteralPath $acao.Destino -Destination $novoSalvo
                }
            } else {
                Assert-NoReparseAncestors $acao.Origem
                Assert-NoReparseAncestors $acao.Destino
                $existeOrigem = Test-AnyPath $acao.Origem
                $existeDestino = Test-AnyPath $acao.Destino
                if ($existeDestino -and -not $existeOrigem) {
                    Ensure-Directory ([IO.Path]::GetDirectoryName($acao.Origem))
                    Move-Item -LiteralPath $acao.Destino -Destination $acao.Origem
                } elseif ($existeDestino -and $existeOrigem) {
                    throw ('Colisao durante rollback; ambos preservados: ' + $acao.Origem + ' e ' + $acao.Destino)
                } elseif (-not $existeOrigem) {
                    throw ('Origem e destino ausentes no rollback: ' + $acao.Origem)
                }
            }
            Write-Journal 'rollback_acao_concluida' $acao
        } catch {
            $falhasRollback.Add($_.Exception.Message)
            try { Write-Journal 'rollback_acao_falhou' ([ordered]@{acao=$acao; erro=$_.Exception.Message}) } catch { }
        }
    }
    if ($falhasRollback.Count -gt 0) {
        Write-Warning ('Rollback incompleto; preserve todos os caminhos e consulte ' + $journalPath)
        foreach ($falha in $falhasRollback) { Write-Warning $falha }
    } else {
        Write-Warning 'Aplicacao interrompida; movimentos e substituicoes foram revertidos. O backup foi mantido.'
    }
    throw $erroAplicacao
}
