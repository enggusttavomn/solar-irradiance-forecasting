from pathlib import Path
import ast
import hashlib
import json
import zipfile
from collections import defaultdict

ROOT = Path(__file__).resolve().parents[1]
STAGE = ROOT/'tmp/reorganizacao_previa_20261027'
REGISTRY = STAGE/'documentacao/organizacao/reorganizacao_codigo_20261027.json'
APPLY = ROOT/'tmp/aplicacao_organizacao_20261027.json'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None

def candidates():
    found=[p for p in STAGE.iterdir() if p.is_file()]
    for folder in ['.github','documentacao','artigos','dados','resultados']:
        for p in (STAGE/folder).rglob('*'):
            if p.is_file() and (p.suffix in ['.md','.csv'] or folder=='.github' or p.relative_to(STAGE).as_posix() in [
                'documentacao/organizacao/reorganizacao_codigo_20261027.json',
                'documentacao/organizacao/fontes_antes_reorganizacao_20261027.zip',
                'resultados/relatorios/panorama_projeto_ghi.html']):
                found.append(p)
    return sorted(set(found))

def before_path(relative):
    if relative.startswith('resultados/relatorios/'):
        return relative.removeprefix('resultados/')
    if relative.startswith('resultados/pdf/'):
        return relative.replace('resultados/pdf/','output/pdf/',1)
    return relative

def tests(text):
    found=[]
    def visit(node,prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child,ast.ClassDef):
                visit(child,prefix+child.name+'.')
            elif isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):
                if child.name.startswith('test_'): found.append(prefix+child.name)
            else: visit(child,prefix)
    visit(ast.parse(text))
    return found

record=json.loads(REGISTRY.read_text(encoding='utf-8'))
source_archive=STAGE/record['fontes_arquivadas']
expected=defaultdict(list)
with zipfile.ZipFile(source_archive) as archive:
    for name in archive.namelist():
        if name.startswith(('testes/','tests/')) and name.endswith('.py'):
            target=record['arquivos'].get(name,name)
            for test in tests(archive.read(name).decode('utf-8-sig')):
                expected[(target,test)].append(name)
rename={'test_manifesto_referencia_os_bytes_atuais':'test_manifesto_referencia_os_bytes_originais_preservados'}
for (name,test),originals in expected.items():
    assert len(originals)==1, ('colisão',name,test)
    assert rename.get(test,test) in tests((STAGE/name).read_text(encoding='utf-8')),('teste ausente',name,test)

# Preserve original documentation too, especially protocols mentioned by old SHA snapshots.
added=0
with zipfile.ZipFile(source_archive,'a',compression=zipfile.ZIP_DEFLATED) as archive:
    members=set(archive.namelist())
    for p in candidates():
        relative=p.relative_to(STAGE).as_posix()
        if p.suffix=='.zip': continue
        old=before_path(relative); original=ROOT/old
        if original.is_file() and sha(original)!=sha(p) and old not in members:
            data=original.read_bytes()
            archive.writestr(old,data)
            members.add(old)
            record['fontes_antes'][old]=hashlib.sha256(data).hexdigest()
            added+=1
record['sha256_arquivo_fontes']=sha(source_archive)
record['verificacoes_finais']={
    'testes_previa':'1433 passed, 8 skipped, 319 subtests passed in 136.59s',
    'definicoes_de_teste_originais_preservadas':sum(len(x) for x in expected.values()),
    'teste_renomeado':rename,
    'links_locais_validos':191,
    'cli_catalogo':18,
    'fontes_python_com_sintaxe_valida':251,
}
record['fontes_depois']={p.relative_to(STAGE).as_posix():sha(p) for folder in ['codigo_fonte','testes'] for p in sorted((STAGE/folder).rglob('*.py'))}
REGISTRY.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

# Check that the untouched live tree still matches the source from which the preview was built.
for name,digest in record['fontes_antes'].items():
    assert sha(ROOT/name)==digest,('arquivo alterado em paralelo',name)
updates=[]
for p in candidates():
    relative=p.relative_to(STAGE).as_posix()
    before=sha(ROOT/before_path(relative)); after=sha(p)
    if before!=after:
        updates.append({'destino':relative,'sha256_antes':before,'sha256_depois':after})
plan={'raiz':str(ROOT),'previa':str(STAGE),'backup':'tmp/reorganizacao_backup_20261027',
      'substituicoes':updates,'verificacoes':record['verificacoes_finais'],
      'artefatos_preservados':record['verificacao_artefatos']}
APPLY.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Plano final:',len(updates),'substituições de documentos/configurações; 949 definições de testes originais preservadas.')
print('Documentos originais acrescentados ao arquivo histórico:',added)
print('Preflight: todos os',len(record['fontes_antes']),'arquivos da árvore atual conferem com o snapshot inicial.')
