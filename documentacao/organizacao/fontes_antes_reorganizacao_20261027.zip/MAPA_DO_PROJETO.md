# Mapa do projeto de previsão solar

Para navegar pelo navegador, abra o [panorama visual](relatorios/panorama_projeto_ghi.html).
Para instalar e executar o projeto, consulte o [README](README.md).

## Onde está cada coisa

| Quero encontrar… | Pasta ou arquivo | O que contém |
|---|---|---|
| O artigo principal | [artigos/revista_unificado/](artigos/revista_unificado/) | manuscrito de revista, figuras, tabelas e suplemento |
| Os outros artigos | [artigos/](artigos/) | IEEE (estudo horário), BTSym'26 (mensal), MCSM (histórico) e templates |
| O plano do TCC | [documentacao/plano_de_trabalho/](documentacao/plano_de_trabalho/) | plano de trabalho EA019 |
| O que foi entregue aos orientadores | [documentacao/entregas_aos_orientadores/](documentacao/entregas_aos_orientadores/) | pacotes completos separados por data |
| Artigos e materiais de consulta | [documentacao/materiais_de_referencia/](documentacao/materiais_de_referencia/) | PDFs, imagens, modelos e versões anteriores |
| Os protocolos e guias | [documentacao/README.md](documentacao/README.md) | otimização, quantização, revisão bibliográfica e resultados resumidos |
| O código da pesquisa | [codigo_fonte/](codigo_fonte/) | coleta, preparação, modelos, métricas e experimentos |
| Um comando para executar | [scripts/COMANDOS.md](scripts/COMANDOS.md) | catálogo por finalidade |
| Os testes | [testes/](testes/) e [tests/](tests/) | testes científicos, operacionais e contratos históricos |
| Os dados de entrada | [dados/](dados/) | dados brutos, fontes externas e bases processadas |
| Os resultados da pesquisa | [resultados/README.md](resultados/README.md) | fontes atuais, resultados históricos e critérios de publicação |
| Auditorias e acompanhamento | [relatorios/](relatorios/) | registros datados e painéis |
| Os PDFs exportados | [output/pdf/](output/pdf/) | cópias para leitura e entrega |
| Trabalho temporário e recuperação | [tmp/](tmp/) | prévias, testes rápidos, scripts e estados locais de retomada |

## Código e comandos

```text
codigo_fonte/                   lógica reutilizável da pesquisa
  coleta/                       acesso à API e cadastro das localidades
  preparacao/                   limpeza e construção das bases
  modelos/                      modelos separados por família
    referencias_simples/        persistência, sazonal ingênuo e climatologia
    tabulares/                  XGBoost e MLP
    recorrentes/                RNN, LSTM e DilatedRNN
    probabilisticos/            DeepAR e DeepNPTS
  experimento/                  avaliação, métricas e reprodutibilidade
  visualizacao/                 figuras dos resultados

scripts/                        comandos organizados por finalidade
  coleta/                       obter e preparar dados
  treinamento/                  executar avaliações, buscas e quantização
  auditoria/                    verificar experimentos e artefatos
  relatorios/                   gerar figuras e PDFs
  operacao/                     acompanhar treinamentos
  apresentacoes/                gerar e revisar slides

executaveis/                    implementações históricas de comandos
testes/                         testes científicos e testes novos
  operacao/                     testes de acompanhamento e operação local
tests/                          testes com caminhos históricos auditados
```

Os arquivos diretamente em `codigo_fonte/`, `scripts/` e na raiz ainda incluem
implementações antigas. Os módulos organizados reaproveitam essas implementações;
não são cópias independentes para apagar. Por exemplo, `codigo_fonte/modelos.py`
e a pasta `codigo_fonte/modelos/` têm papéis diferentes.

Execute os comandos a partir da raiz. No PowerShell, o Python instalado neste
checkout está em `.venv\Scripts\python.exe`. Exemplo de consulta à ajuda:

```powershell
.\.venv\Scripts\python.exe -m scripts.treinamento.rodar_quantizacao_todos_modelos --help
```

## Dados e resultados: como distinguir

| Caminho | Significado |
|---|---|
| `dados/brutos/localidades_ev/` | dados diários, 2019–2024 |
| `dados/brutos/localidades_ev_horario/` | dados horários, 2019–2024 |
| `dados/brutos/localidades_ev_1998_2022/` | histórico de médias **diárias**, 1998–2022 |
| `dados/brutos/localidades_ev_horario_1998_2022/` | histórico horário e amostras de 30 minutos |
| `dados/brutos/localidades_ev_mensal_1998_2022/` | histórico de médias mensais |
| `dados/externos/` | classificação climática e contexto meteorológico |
| `dados/processados/` | atributos preparados de fluxos anteriores |
| `resultados/avaliacao_multirresolucao_corrigida_v2/` | fonte atual local das quatro tarefas do artigo principal |
| `resultados/avaliacao_mensal_canonica/` | avaliação mensal anterior preservada |
| `resultados/avaliacao_horaria_timesnet/` | avaliação horária original do estudo IEEE |

As versões diária, horária e mensal não são duplicatas. O índice de resultados
identifica o papel científico de cada execução; a palavra `corrigida`, `final`
ou `legado` no nome, sozinha, não determina o que pode ser publicado ou apagado.

## Organização realizada em 27/10/2026

| Nome anterior | Nome atual |
|---|---|
| `documentacao/envios/` | `documentacao/entregas_aos_orientadores/` |
| `documentacao/referencias_legadas/` | `documentacao/materiais_de_referencia/` |

O conteúdo das duas pastas foi mantido byte a byte. O
[registro de organização](documentacao/organizacao/registro_de_organizacao_20261027.json)
lista os caminhos antigos e novos, os hashes de cada arquivo e a limpeza
executada. Referências dentro de evidências históricas continuam registrando o
caminho da época; esse registro permite localizar o arquivo depois da mudança.

O [inventário de pastas](documentacao/organizacao/inventario_de_pastas.csv)
mostra quantidade de arquivos e tamanho por pasta, até o segundo nível.
Ambientes, ferramentas, Git e caches ficam fora desse inventário.

## O que conservar e onde salvar arquivos novos

Mantenha dados, modelos treinados, métricas, manifestos, artigos e pacotes de
entrega. Eles registram o que foi produzido em cada etapa da pesquisa. Os PDFs
repetidos entre `output/pdf/` e `documentacao/` também aparecem em rotinas
históricas de entrega e foram conservados.

`tmp/` mistura renderizações com scripts únicos e estados de recuperação;
não é uma pasta inteiramente descartável. Caches Python e diretórios de trabalho
do pytest podem ser recriados e foram tratados separadamente na limpeza.

Para arquivos novos, use nomes que indiquem assunto e finalidade, em português:

| Arquivo novo | Destino |
|---|---|
| Código reutilizável | `codigo_fonte/<etapa>/` |
| Comando | `scripts/<finalidade>/` |
| Teste | `testes/` ou `testes/operacao/` |
| Experimento e suas evidências | `resultados/<assunto>_<AAAAMMDD>/` |
| Auditoria ou revisão | `relatorios/<assunto>_<AAAAMMDD>/` |
| Entrega | `documentacao/entregas_aos_orientadores/<assunto>_<AAAAMMDD>/` |
| Material de consulta | `documentacao/materiais_de_referencia/` |
| Prévia regenerável | `output/<assunto>_<AAAAMMDD>/` |

`output/`, `tmp/`, `tests/` e os caminhos dos experimentos existentes foram
mantidos para preservar as chamadas de scripts e os contratos de auditoria.
`.venv/` é o ambiente Python; `.tools/` contém ferramentas usadas por esse
ambiente; `.git/` guarda o histórico. Essas pastas técnicas são necessárias.
